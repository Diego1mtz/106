# PROC106-V1-plantilla-proyecto
Detectar al peatón.  
  
### Texto en inglés: PRO-C106-ProjectTemplate
